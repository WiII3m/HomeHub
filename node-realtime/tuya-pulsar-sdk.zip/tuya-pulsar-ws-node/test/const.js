const accessKey = 'accessKeyesttesttesttesttesttest';
const accessId = 'accessIdtesttesttest';
const originData = {
  dataId: 'dataIddataIddataIddataId',
  devId: 'devIddevIddevIddevIddevId',
  productKey: 'productKeypro',
  status: [
    {
      code: 'code',
      t: 1622449865296,
      value: 280,
    },
  ],
};
const encryptCode =
  '9Pe6AYEE2fJyCh5gcY/+mCY2yhFsxZ6Pjt+n1WkotuvVHRAKjf+aV+HPMrx55iSk1ot9TiUZkiufxWreZ7VMEJ3uo8iT992qq4w+mnjTfi/Ph9hyB3UJTQOlkdChT93LYnQGgEqWrY77X2vgC6bIKUGgCV2mD0A1a2QwO0gXtPhQabf1RL9SdVUUqqMJKgAEEYdqygcT/V08yNDgSAnIMQ==';

module.exports = {
  accessKey,
  accessId,
  originData,
  encryptCode,
};
